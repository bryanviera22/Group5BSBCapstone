package com.company.consolesdao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsolesDaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsolesDaoApplication.class, args);
	}

}
