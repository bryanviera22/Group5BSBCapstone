package com.company.BriannaJohnsonCapstone.gameDao.model;

public class ESRBRating {
    private int id;
    private String ESRBRating;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getESRBRating() {
        return ESRBRating;
    }

    public void setESRBRating(String ESRBRating) {
        this.ESRBRating = ESRBRating;
    }
}
