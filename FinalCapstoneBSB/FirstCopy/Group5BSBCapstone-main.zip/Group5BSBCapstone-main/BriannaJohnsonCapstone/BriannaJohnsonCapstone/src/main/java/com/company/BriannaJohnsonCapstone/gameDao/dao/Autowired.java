package com.company.BriannaJohnsonCapstone.gameDao.dao;

public @interface Autowired {
}
