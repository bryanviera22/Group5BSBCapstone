package com.company.BriannaJohnsonCapstone.gameDao.controller;

public @interface RestController {
}
