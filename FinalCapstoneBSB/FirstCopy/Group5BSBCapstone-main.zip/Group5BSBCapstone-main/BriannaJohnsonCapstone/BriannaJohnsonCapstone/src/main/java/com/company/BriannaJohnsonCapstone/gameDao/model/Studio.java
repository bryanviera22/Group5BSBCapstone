package com.company.BriannaJohnsonCapstone.gameDao.model;

public class Studio {
    private int id;
    private String studio;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStudio() {
        return studio;
    }

    public void setStudio(String studio) {
        this.studio = studio;
    }
}
