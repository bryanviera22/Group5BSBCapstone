package com.company.BriannaJohnsonCapstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BriannaJohnsonCapstoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
