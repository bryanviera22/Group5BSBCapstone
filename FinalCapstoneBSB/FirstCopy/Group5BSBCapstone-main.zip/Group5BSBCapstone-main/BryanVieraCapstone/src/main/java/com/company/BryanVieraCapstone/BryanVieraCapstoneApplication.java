package com.company.BryanVieraCapstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BryanVieraCapstoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(BryanVieraCapstoneApplication.class, args);
	}

}
