package com.company.BryanVieraCapstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BryanVieraCapstoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
